import { useState } from 'react';
import { 
  Stethoscope, ClipboardList, Calendar, Users, LayoutDashboard, Menu, X 
} from 'lucide-react';

const N_NAV = [
  { p:'intake', l:'Patient Intake', ic:<ClipboardList size={15}/> },
  { p:'reg', l:'Book Appointment', ic:<Calendar size={15}/> },
  { p:'appts', l:'Appointments', ic:<Calendar size={15}/> },
  { p:'nur-pts', l:'Patient Directory', ic:<Users size={15}/> },
];

const D_NAV = [
  { p:'doc-dash', l:'Dashboard', ic:<LayoutDashboard size={15}/> },
  { p:'doc-appts', l:'Appointments', ic:<Calendar size={15}/> },
  { p:'doc-pts', l:'Patients', ic:<Users size={15}/> },
];

export function Sidebar({ portal, setPortal, page, setPage }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const nav = portal === 'nurse' ? N_NAV : D_NAV;
  const u = portal === 'nurse'
    ? { nm:'R. Preethi', rl:'Receptionist', av:'RP' }
    : { nm:'Dr. Kavitha Iyer', rl:'General Medicine', av:'KI' };

  const handleNav = (p) => {
    setPage(p);
    setMobileOpen(false);
  };

  return (
    <aside className="sb">
      <div className="sb-logo">
        <div className="logo-b">
          <div className="logo-ic"><Stethoscope size={17} color="#fff"/></div>
          <div><div className="logo-tx">EvoDoc</div><div className="logo-sub">Healthcare Portal</div></div>
        </div>
        <button className="sb-mobile-btn" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      <div className={`sb-content ${mobileOpen ? 'open' : ''}`}>
        <div style={{padding:'10px 12px 0'}}>
          <div className="pt-sw">
            <button className={`pt-b${portal==='nurse'?' on':''}`} onClick={()=>{setPortal('nurse'); handleNav('appts');}}>Nurse / Recep.</button>
            <button className={`pt-b${portal==='doctor'?' on':''}`} onClick={()=>{setPortal('doctor'); handleNav('doc-dash');}}>Doctor</button>
          </div>
        </div>
        
        <nav className="nav-s">
          <div className="nav-lb">Navigation</div>
          {nav.map(n=>(
            <button key={n.p} className={`nav-i${page===n.p||page.startsWith(n.p)?' on':''}`} onClick={()=>handleNav(n.p)}>
              {n.ic}{n.l}
            </button>
          ))}
        </nav>
        
        <div className="sb-ft">
          <div className="u-card">
            <div className="u-av">{u.av}</div>
            <div><div className="u-nm">{u.nm}</div><div className="u-rl">{u.rl}</div></div>
          </div>
        </div>
      </div>
    </aside>
  );
}

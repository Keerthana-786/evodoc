import React, { useState, useMemo } from 'react';
import { Search, Filter, Calendar, Trash2 } from 'lucide-react';
import { useAppContext } from '../../hooks/AppContext';
import { EmptyState, Badge, Modal } from '../../components/UIComponents';
import { formatDate, formatTime, getToday } from '../../utils/helpers';

export default function DoctorAppointments() {
  const { appointments, doctors, updateAppointmentStatus, addToast } = useAppContext();

  // Assuming the first doctor is logged in (in a real app, use auth context)
  const currentDoctor = doctors[0];

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [viewMode, setViewMode] = useState('upcoming'); // 'upcoming', 'past', 'all'
  const [dateFilter, setDateFilter] = useState(''); // Specific date via picker
  const [selectedAppt, setSelectedAppt] = useState(null);

  // Filter appointments for current doctor
  const filtered = useMemo(() => {
    let result = appointments.filter(a => a.doctorId === currentDoctor?.id);

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.patient.toLowerCase().includes(q) ||
        a.notes?.toLowerCase().includes(q)
      );
    }

    // Time filter
    const today = getToday();
    
    // Explicit date filter overrides viewMode
    if (dateFilter) {
      result = result.filter(a => a.date === dateFilter);
    } else {
      if (viewMode === 'upcoming') {
        result = result.filter(a => a.date >= today);
      } else if (viewMode === 'past') {
        result = result.filter(a => a.date < today);
      }
    }

    // Status filter
    if (statusFilter !== 'all') {
      result = result.filter(a => a.status === statusFilter);
    }

    // Sort by time
    result.sort((a, b) => {
      if (a.date === b.date) {
        return a.time.localeCompare(b.time);
      }
      return new Date(a.date) - new Date(b.date);
    });

    return result;
  }, [appointments, currentDoctor?.id, searchQuery, statusFilter, viewMode, dateFilter]);

  const handleStatusChange = (apptId, newStatus) => {
    updateAppointmentStatus(apptId, newStatus);
    setSelectedAppt(null);
  };

  const stats = {
    today: appointments.filter(a => a.doctorId === currentDoctor?.id && a.date === getToday()).length,
    scheduled: appointments.filter(a => a.doctorId === currentDoctor?.id && a.status === 'scheduled').length,
    completed: appointments.filter(a => a.doctorId === currentDoctor?.id && a.status === 'completed').length,
    cancelled: appointments.filter(a => a.doctorId === currentDoctor?.id && a.status === 'cancelled').length
  };

  const getStatusClass = (status) => {
    return `status-${status}`;
  };

  return (
    <div className="pe">
      {/* HEADER */}
      <div style={{marginBottom: 24}}>
        <div style={{fontSize: 14, fontWeight: 700, color: 'var(--tx)', marginBottom: 16}}>
          Your Appointments
        </div>

        {/* Filter Cards */}
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12}}>
          {[
            {label: 'Today', value: stats.today, color: 'var(--inf)'},
            {label: 'Scheduled', value: stats.scheduled, color: 'var(--wn)'},
            {label: 'Completed', value: stats.completed, color: 'var(--ok)'},
            {label: 'Cancelled', value: stats.cancelled, color: 'var(--er)'}
          ].map(stat => (
            <div
              key={stat.label}
              onClick={() => {
                if (stat.label === 'Today') {
                  setViewMode('upcoming');
                  setStatusFilter('all');
                } else {
                  setStatusFilter(stat.label.toLowerCase());
                }
              }}
              style={{
                padding: 12,
                textAlign: 'center',
                background: 'var(--wh)',
                border: '1px solid var(--bd)',
                borderRadius: 'var(--rl)',
                cursor: 'pointer',
                transition: 'all .15s'
              }}
              className="stat-card"
            >
              <div style={{fontSize: 12, color: 'var(--t3)', fontWeight: 600, marginBottom: 6}}>
                {stat.label}
              </div>
              <div style={{fontSize: 20, fontWeight: 700, color: stat.color}}>
                {stat.value}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FILTER CONTROLS */}
      <div className="card" style={{marginBottom: 18}}>
        <div className="c-bd">
          <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr 1fr auto', gap: 12, marginBottom: 12, alignItems: 'center'}}>
            {/* Search */}
            <div className="search-wrapper">
              <Search size={16} className="search-icon" />
              <input
                type="text"
                placeholder="Search patient..."
                className="search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Status Filter */}
            <select
              className="fsl"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="scheduled">Scheduled</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>

            {/* Date Filter */}
            <div className="search-wrapper" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ position: 'relative', flex: 1 }}>
                <Calendar size={16} className="search-icon" />
                <input
                  type="date"
                  className="search-input"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>
              {dateFilter && (
                <button
                  className="btn-icon"
                  title="Clear Date Filter"
                  onClick={() => setDateFilter('')}
                >
                  ✕
                </button>
              )}
            </div>

            {/* View Mode Toggle is still useful but we can integrate date filter properly */}
            <div className="tabs" style={{marginBottom: 0, border: 'none'}}>
              <button 
                className={`tab ${viewMode === 'upcoming' ? 'on' : ''}`}
                onClick={() => setViewMode('upcoming')}
              >Upcoming</button>
              <button 
                className={`tab ${viewMode === 'past' ? 'on' : ''}`}
                onClick={() => setViewMode('past')}
              >Past</button>
              <button 
                className={`tab ${viewMode === 'all' ? 'on' : ''}`}
                onClick={() => setViewMode('all')}
              >All Dates</button>
            </div>
          </div>
        </div>
      </div>

      {/* APPOINTMENTS LIST */}
      <div className="card">
        <div className="c-hd">
          <div className="c-t">
            {viewMode === 'upcoming' ? 'Upcoming Appointments' : viewMode === 'past' ? 'Past Appointments' : 'All Your Appointments'}
          </div>
          <div style={{fontSize: 12, color: 'var(--t3)'}}>{filtered.length} result{filtered.length !== 1 ? 's' : ''}</div>
        </div>

        <div className="c-bd">
          {filtered.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No Appointments"
              message={`You have no ${viewMode === 'all' ? '' : viewMode} appointments matching your filters.`}
            />
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
              {filtered.map(appt => (
                <div
                  key={appt.id}
                  onClick={() => setSelectedAppt(appt)}
                  className="appointment-card"
                  style={{
                    opacity: appt.status === 'cancelled' ? 0.6 : 1,
                    backgroundColor: appt.status === 'completed' ? '#f0fdf4' : 'var(--wh)'
                  }}
                >
                  {/* Time */}
                  <div className="at-b" style={{
                    background: appt.status === 'completed' ? 'var(--okbg)' : 'var(--wnbg)',
                    color: appt.status === 'completed' ? 'var(--ok)' : 'var(--wn)'
                  }}>
                    <div className="at-h">{formatTime(appt.time)}</div>
                    <div className="at-d" style={{fontSize: 10}}>{formatDate(appt.date).split(' ')[0]}</div>
                  </div>

                  {/* Content */}
                  <div className="a-inf">
                    <div className="a-pt">{appt.patient}</div>
                    <div className="a-mt" style={{display: 'flex', gap: 8, alignItems: 'center', marginTop: 6}}>
                      <Badge s={appt.status} />
                      <span style={{fontSize: 11, color: 'var(--t3)'}}>{appt.type}</span>
                      {appt.notes && <span style={{fontSize: 11, color: 'var(--t3)'}}>• {appt.notes.substring(0, 30)}</span>}
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div style={{display: 'flex', gap: 6}}>
                    {appt.status === 'scheduled' && (
                      <>
                        <button
                          className="btn-icon primary"
                          title="Complete"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStatusChange(appt.id, 'completed');
                          }}
                        >
                          ✓
                        </button>
                        <button
                          className="btn-icon"
                          title="Cancel"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStatusChange(appt.id, 'cancelled');
                          }}
                        >
                          ✕
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* APPOINTMENT DETAILS MODAL */}
      {selectedAppt && (
        <Modal
          open={true}
          onClose={() => setSelectedAppt(null)}
          title={`Appointment - ${selectedAppt.patient}`}
          actions={[
            ...(selectedAppt.status === 'scheduled' ? [
              <button
                key="complete"
                className="btn btn-p sm"
                onClick={() => handleStatusChange(selectedAppt.id, 'completed')}
              >
                Mark Completed
              </button>,
              <button
                key="cancel"
                className="btn btn-s sm"
                onClick={() => handleStatusChange(selectedAppt.id, 'cancelled')}
              >
                Cancel
              </button>
            ] : []),
            <button
              key="view-patient"
              className="btn btn-p sm"
              onClick={() => {
                setSelectedAppt(null);
                document.querySelector('.nav-i:nth-child(3)')?.click();
              }}
            >
              View Full Record
            </button>,
            <button key="close" className="btn btn-s sm" onClick={() => setSelectedAppt(null)}>
              Close
            </button>
          ]}
        >
          <div style={{fontSize: 13, display: 'flex', flexDirection: 'column', gap: 14}}>
            <div>
              <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                Patient
              </div>
              <div style={{fontSize: 13, color: 'var(--tx)'}}>{selectedAppt.patient}</div>
            </div>

            <div>
              <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                Date & Time
              </div>
              <div style={{fontSize: 13, color: 'var(--tx)'}}>
                {formatDate(selectedAppt.date)} at {formatTime(selectedAppt.time)}
              </div>
            </div>

            <div>
              <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                Type
              </div>
              <div style={{fontSize: 13, color: 'var(--tx)'}}>{selectedAppt.type}</div>
            </div>

            <div>
              <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                Status
              </div>
              <Badge s={selectedAppt.status} />
            </div>

            {selectedAppt.notes && (
              <div>
                <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                  Notes
                </div>
                <div style={{fontSize: 13, color: 'var(--tx)', lineHeight: 1.5}}>
                  {selectedAppt.notes}
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}

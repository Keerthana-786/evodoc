import React, { useState, useMemo } from 'react';
import { Edit, Save, X, Plus, History } from 'lucide-react';
import { useAppContext } from '../../hooks/AppContext';
import { Input, Sel, Area, SecTitle, Badge, EmptyState, Modal } from '../../components/UIComponents';
import { formatDate, calculateAge } from '../../utils/helpers';

export default function PatientDetails({ patientId: passedPatientId }) {
  const { patients, getPatientById, updatePatient, getNotesByPatient, appointments, addNote, addToast } = useAppContext();

  // For demo purposes, use first patient or passed ID
  const [selectedPatientId, setSelectedPatientId] = useState(passedPatientId || (patients[0]?.id || null));
  const patient = patients.find(p => p.id === selectedPatientId);

  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState(null);
  const [errors, setErrors] = useState({});
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [noteForm, setNoteForm] = useState({ note: '', doctorName: 'Dr. Kavitha Iyer' });

  // Patient's appointments
  const patientAppts = useMemo(() => {
    if (!patient) return [];
    return appointments
      .filter(a => a.patientId === patient.id)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [patient, appointments]);

  // Patient's clinical notes
  const patientNotes = useMemo(() => {
    if (!patient) return [];
    return getNotesByPatient(patient.id);
  }, [patient, getNotesByPatient]);

  // Initialize edit form
  const handleEditStart = () => {
    if (!patient) return;
    setEditForm({ ...patient });
    setIsEditing(true);
    setErrors({});
  };

  const handleEditCancel = () => {
    setIsEditing(false);
    setEditForm(null);
    setErrors({});
  };

  const validateEdit = () => {
    const e = {};
    if (!editForm.name?.trim()) e.name = 'Name is required';
    if (!editForm.contact?.trim()) e.contact = 'Contact is required';
    if (!editForm.blood) e.blood = 'Blood group is required';
    return e;
  };

  const handleEditSave = () => {
    const e = validateEdit();
    setErrors(e);
    if (Object.keys(e).length === 0) {
      updatePatient(patient.id, editForm);
      setIsEditing(false);
      setEditForm(null);
    }
  };

  const handleAddNote = () => {
    if (!noteForm.note.trim()) {
      addToast('Please enter a note', 'error');
      return;
    }
    addNote({
      patientId: patient.id,
      doctor: noteForm.doctorName,
      note: noteForm.note
    });
    setNoteForm({ note: '', doctorName: 'Dr. Kavitha Iyer' });
    setShowNoteModal(false);
  };

  if (!patient && patients.length === 0) {
    return (
      <div className="pe">
        <EmptyState
          icon={History}
          title="No Patients Found"
          message="There are no patients in the system yet."
        />
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="pe">
        <EmptyState
          icon={History}
          title="Select a Patient"
          message="Choose a patient from the list to view their details."
        />
      </div>
    );
  }

  return (
    <div className="pe">
      {/* PATIENT SELECTOR */}
      {patients.length > 1 && (
        <div style={{marginBottom: 18}}>
          <select
            className="fsl"
            value={selectedPatientId}
            onChange={(e) => setSelectedPatientId(parseInt(e.target.value))}
            style={{minWidth: 300}}
          >
            {patients.map(p => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.contact})
              </option>
            ))}
          </select>
        </div>
      )}

      {/* PATIENT HEADER */}
      <div className="patient-header">
        <div className="patient-avatar">
          {patient.name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
        </div>
        <div style={{flex: 1}}>
          <div className="patient-name">{patient.name}</div>
          <div className="patient-meta">
            <div className="patient-meta-item">📅 {calculateAge(patient.dob)} years old</div>
            <div className="patient-meta-item">👤 {patient.gender || 'Not specified'}</div>
            <div className="patient-meta-item">🩸 {patient.blood || 'Not specified'}</div>
            <div className="patient-meta-item">📞 {patient.contact}</div>
          </div>
        </div>
        <button
          className="btn btn-p"
          onClick={handleEditStart}
          disabled={isEditing}
        >
          <Edit size={13} />
          {isEditing ? 'Editing...' : 'Edit Record'}
        </button>
      </div>

      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18}}>
        {/* MEDICAL INFORMATION */}
        <div className="card">
          <div className="c-hd">
            <div className="c-t">Medical Information</div>
          </div>
          <div className="c-bd">
            {isEditing ? (
              // EDIT MODE
              <div style={{display: 'flex', flexDirection: 'column', gap: 14}}>
                <Input
                  label="Full Name"
                  value={editForm.name}
                  onChange={(e) => setEditForm(p => ({...p, name: e.target.value}))}
                  err={errors.name}
                />

                <Sel
                  label="Blood Group"
                  value={editForm.blood}
                  onChange={(e) => setEditForm(p => ({...p, blood: e.target.value}))}
                  err={errors.blood}
                >
                  <option value="">Select blood group</option>
                  {['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(b=>
                    <option key={b}>{b}</option>
                  )}
                </Sel>

                <Input
                  label="Contact Number"
                  value={editForm.contact}
                  onChange={(e) => setEditForm(p => ({...p, contact: e.target.value}))}
                  err={errors.contact}
                />

                <Input
                  label="Email"
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm(p => ({...p, email: e.target.value}))}
                />

                <Area
                  label="Known Allergies"
                  value={editForm.allergies}
                  onChange={(e) => setEditForm(p => ({...p, allergies: e.target.value}))}
                />

                <Area
                  label="Chronic Conditions"
                  value={editForm.conditions}
                  onChange={(e) => setEditForm(p => ({...p, conditions: e.target.value}))}
                />

                <Area
                  label="Current Medications"
                  value={editForm.medications}
                  onChange={(e) => setEditForm(p => ({...p, medications: e.target.value}))}
                />

                <div style={{display: 'flex', gap: 10}}>
                  <button className="btn btn-s" onClick={handleEditCancel} style={{flex: 1}}>
                    <X size={13} />
                    Cancel
                  </button>
                  <button className="btn btn-p" onClick={handleEditSave} style={{flex: 1}}>
                    <Save size={13} />
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              // VIEW MODE
              <div style={{display: 'flex', flexDirection: 'column', gap: 14}}>
                <div>
                  <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                    Blood Group
                  </div>
                  <div style={{fontSize: 13, color: 'var(--tx)'}}>{patient.blood || 'Not specified'}</div>
                </div>

                <div>
                  <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                    Allergies
                  </div>
                  <div style={{fontSize: 13, color: 'var(--tx)'}}>{patient.allergies || 'None'}</div>
                </div>

                <div>
                  <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                    Chronic Conditions
                  </div>
                  <div style={{fontSize: 13, color: 'var(--tx)'}}>{patient.conditions || 'None'}</div>
                </div>

                <div>
                  <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                    Current Medications
                  </div>
                  <div style={{fontSize: 13, color: 'var(--tx)', lineHeight: 1.6}}>{patient.medications || 'None'}</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* EMERGENCY CONTACT */}
        <div className="card">
          <div className="c-hd">
            <div className="c-t">Emergency Contact</div>
          </div>
          <div className="c-bd">
            <div style={{display: 'flex', flexDirection: 'column', gap: 14}}>
              <div>
                <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                  Name
                </div>
                <div style={{fontSize: 13, color: 'var(--tx)'}}>{patient.emergency?.name || 'Not specified'}</div>
              </div>

              <div>
                <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                  Relationship
                </div>
                <div style={{fontSize: 13, color: 'var(--tx)'}}>{patient.emergency?.relation || 'Not specified'}</div>
              </div>

              <div>
                <div style={{fontSize: 11, fontWeight: 600, color: 'var(--t3)', textTransform: 'uppercase', marginBottom: 4}}>
                  Contact Number
                </div>
                <div style={{fontSize: 13, color: 'var(--tx)'}}>{patient.emergency?.contact || 'Not specified'}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* APPOINTMENT HISTORY */}
      <div className="card" style={{marginTop: 18}}>
        <div className="c-hd">
          <div className="c-t">Appointment History</div>
          <div style={{fontSize: 12, color: 'var(--t3)'}}>{patientAppts.length} appointments</div>
        </div>
        <div className="c-bd">
          {patientAppts.length === 0 ? (
            <EmptyState
              icon={History}
              title="No Appointments"
              message="This patient has no appointment history."
            />
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', gap: 8}}>
              {patientAppts.slice(0, 10).map(appt => (
                <div key={appt.id} style={{
                  padding: 12,
                  background: 'var(--bg)',
                  borderRadius: 'var(--rs)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div>
                    <div style={{fontSize: 13, fontWeight: 500, color: 'var(--tx)'}}>
                      {formatDate(appt.date)} - {appt.doctor}
                    </div>
                    <div style={{fontSize: 11, color: 'var(--t3)', marginTop: 2}}>
                      {appt.type}
                      {appt.notes && ` • ${appt.notes.substring(0, 40)}`}
                    </div>
                  </div>
                  <Badge s={appt.status} />
                </div>
              ))}
              {patientAppts.length > 10 && (
                <div style={{textAlign: 'center', padding: 12, color: 'var(--t3)', fontSize: 12}}>
                  +{patientAppts.length - 10} more appointments
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* CLINICAL NOTES */}
      <div className="card" style={{marginTop: 18}}>
        <div className="c-hd">
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%'}}>
            <div>
              <div className="c-t">Clinical Notes</div>
              <div className="c-s">{patientNotes.length} notes</div>
            </div>
            <button
              className="btn btn-p sm"
              onClick={() => setShowNoteModal(true)}
            >
              <Plus size={12} />
              Add Note
            </button>
          </div>
        </div>
        <div className="c-bd">
          {patientNotes.length === 0 ? (
            <EmptyState
              icon={Plus}
              title="No Clinical Notes"
              message="No clinical notes have been added for this patient yet."
              actionText="Add Note"
              onAction={() => setShowNoteModal(true)}
            />
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
              {patientNotes.map(note => (
                <div key={note.id} className="ni">
                  <div className="nm">
                    <span style={{fontWeight: 600}}>{note.doctor}</span>
                    <span>•</span>
                    <span>{formatDate(note.date)}</span>
                  </div>
                  <div className="nt">{note.note}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ADD NOTE MODAL */}
      <Modal
        open={showNoteModal}
        onClose={() => setShowNoteModal(false)}
        title="Add Clinical Note"
        actions={[
          <button
            key="cancel"
            className="btn btn-s sm"
            onClick={() => setShowNoteModal(false)}
          >
            Cancel
          </button>,
          <button
            key="add"
            className="btn btn-p sm"
            onClick={handleAddNote}
          >
            <Plus size={12} />
            Add Note
          </button>
        ]}
      >
        <div style={{display: 'flex', flexDirection: 'column', gap: 14}}>
          <Input
            label="Doctor Name"
            value={noteForm.doctorName}
            onChange={(e) => setNoteForm(p => ({...p, doctorName: e.target.value}))}
          />
          <Area
            label="Clinical Note"
            placeholder="Enter your clinical observations and findings..."
            value={noteForm.note}
            onChange={(e) => setNoteForm(p => ({...p, note: e.target.value}))}
            style={{minHeight: 120}}
          />
        </div>
      </Modal>
    </div>
  );
}

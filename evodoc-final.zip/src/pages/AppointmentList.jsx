import React, { useState, useMemo } from 'react';
import { Filter, Trash2, CheckCircle, XCircle, Search, Edit } from 'lucide-react';
import { useAppContext } from '../../hooks/AppContext';
import { EmptyState, Badge, ConfirmDialog, Modal } from '../../components/UIComponents';
import { formatDate, formatTime } from '../../utils/helpers';

export default function AppointmentList() {
  const { appointments, updateAppointmentStatus, patients, doctors, addToast } = useAppContext();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all'); // all, scheduled, completed, cancelled
  const [dateFilter, setDateFilter] = useState('all'); // all, today, upcoming, past
  const [doctorFilter, setDoctorFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date-asc'); // date-asc, date-desc, patient, doctor

  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [selectedAppt, setSelectedAppt] = useState(null);

  // Filtering & Searching
  const filtered = useMemo(() => {
    let result = [...appointments];
    const today = new Date().toISOString().split('T')[0];

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.patient.toLowerCase().includes(q) ||
        a.doctor.toLowerCase().includes(q) ||
        a.notes?.toLowerCase().includes(q)
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      result = result.filter(a => a.status === statusFilter);
    }

    // Doctor filter
    if (doctorFilter !== 'all') {
      result = result.filter(a => a.doctorId.toString() === doctorFilter);
    }

    // Date filter
    if (dateFilter === 'today') {
      result = result.filter(a => a.date === today);
    } else if (dateFilter === 'upcoming') {
      result = result.filter(a => a.date >= today && a.status === 'scheduled');
    } else if (dateFilter === 'past') {
      result = result.filter(a => a.date < today);
    }

    // Sorting
    if (sortBy === 'date-asc') {
      result.sort((a, b) => new Date(a.date) - new Date(b.date));
    } else if (sortBy === 'date-desc') {
      result.sort((a, b) => new Date(b.date) - new Date(a.date));
    } else if (sortBy === 'patient') {
      result.sort((a, b) => a.patient.localeCompare(b.patient));
    } else if (sortBy === 'doctor') {
      result.sort((a, b) => a.doctor.localeCompare(b.doctor));
    }

    return result;
  }, [appointments, searchQuery, statusFilter, dateFilter, doctorFilter, sortBy]);

  const handleStatusChange = (apptId, newStatus) => {
    updateAppointmentStatus(apptId, newStatus);
  };

  const handleDelete = (apptId) => {
    // Note: In a production app, you'd have a deleteAppointment method
    // For now, we'll just show a not-implemented message
    addToast('Delete functionality coming soon', 'info');
  };

  const stats = {
    total: appointments.length,
    scheduled: appointments.filter(a => a.status === 'scheduled').length,
    completed: appointments.filter(a => a.status === 'completed').length,
    cancelled: appointments.filter(a => a.status === 'cancelled').length
  };

  return (
    <div className="pe">
      {/* STATISTICS */}
      <div className="stat-grid">
        <div className="stat-card" style={{cursor: 'pointer'}} onClick={() => setStatusFilter('all')}>
          <div className="stat-card-label">Total Appointments</div>
          <div className="stat-card-value">{stats.total}</div>
        </div>
        <div className="stat-card" style={{borderLeft: '3px solid var(--inf)', cursor: 'pointer'}} onClick={() => setStatusFilter('scheduled')}>
          <div className="stat-card-label">Scheduled</div>
          <div className="stat-card-value" style={{color: 'var(--inf)'}}>{stats.scheduled}</div>
        </div>
        <div className="stat-card" style={{borderLeft: '3px solid var(--ok)', cursor: 'pointer'}} onClick={() => setStatusFilter('completed')}>
          <div className="stat-card-label">Completed</div>
          <div className="stat-card-value" style={{color: 'var(--ok)'}}>{stats.completed}</div>
        </div>
        <div className="stat-card" style={{borderLeft: '3px solid var(--er)', cursor: 'pointer'}} onClick={() => setStatusFilter('cancelled')}>
          <div className="stat-card-label">Cancelled</div>
          <div className="stat-card-value" style={{color: 'var(--er)'}}>{stats.cancelled}</div>
        </div>
      </div>

      {/* FILTERS & SEARCH */}
      <div className="card" style={{marginBottom: 18}}>
        <div className="c-bd">
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 14}}>
            {/* Search */}
            <div className="search-wrapper">
              <Search size={16} className="search-icon" />
              <input
                type="text"
                placeholder="Search patient, doctor, notes..."
                className="search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Status Filter */}
            <select
              className="fsl"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="scheduled">Scheduled</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>

            {/* Date Filter */}
            <select
              className="fsl"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="upcoming">Upcoming</option>
              <option value="past">Past</option>
            </select>

            {/* Doctor Filter */}
            <select
              className="fsl"
              value={doctorFilter}
              onChange={(e) => setDoctorFilter(e.target.value)}
            >
              <option value="all">All Doctors</option>
              {doctors.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          {/* Sort */}
          <div style={{display: 'flex', gap: 10, justifyContent: 'space-between', alignItems: 'center'}}>
            <div style={{fontSize: 12, color: 'var(--t3)', fontWeight: 600}}>
              {filtered.length} result{filtered.length !== 1 ? 's' : ''}
            </div>
            <select
              className="fsl"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              style={{width: 'auto', minWidth: 140}}
            >
              <option value="date-asc">Date (Oldest)</option>
              <option value="date-desc">Date (Newest)</option>
              <option value="patient">Patient Name</option>
              <option value="doctor">Doctor Name</option>
            </select>
          </div>
        </div>
      </div>

      {/* APPOINTMENT LIST */}
      <div className="card">
        <div className="c-hd">
          <div className="c-t">Appointments</div>
        </div>
        <div className="c-bd">
          {filtered.length === 0 ? (
            <EmptyState
              icon={Filter}
              title="No Appointments Found"
              message={appointments.length === 0 ? "No appointments have been created yet." : "No appointments match your filters. Try adjusting your search."}
            />
          ) : (
            <div style={{overflowX: 'auto'}}>
              <div className="tbl-w">
                <table className="tbl-hover">
                  <thead>
                    <tr>
                      <th>Patient</th>
                      <th>Doctor</th>
                      <th>Date & Time</th>
                      <th>Type</th>
                      <th>Status</th>
                      <th>Notes</th>
                      <th style={{textAlign: 'center'}}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map(appt => (
                      <tr key={appt.id} className={`appt-row appt-${appt.status}`}>
                        <td>
                          <div style={{fontWeight: 500}}>{appt.patient}</div>
                          <div style={{fontSize: 11, color: 'var(--t3)'}}>ID: {appt.patientId}</div>
                        </td>
                        <td>
                          <div style={{fontWeight: 500}}>{appt.doctor}</div>
                          <div style={{fontSize: 11, color: 'var(--t3)'}}># {appt.doctorId}</div>
                        </td>
                        <td>
                          <div style={{fontFamily: 'monospace', fontWeight: 500}}>
                            {formatDate(appt.date)}
                          </div>
                          <div style={{fontSize: 11, color: 'var(--t3)'}}>
                            {formatTime(appt.time)}
                          </div>
                        </td>
                        <td>{appt.type}</td>
                        <td>
                          <Badge s={appt.status} />
                        </td>
                        <td style={{fontSize: 12, color: 'var(--t2)', maxWidth: 150}}>
                          {appt.notes ? appt.notes.substring(0, 50) + (appt.notes.length > 50 ? '...' : '') : '-'}
                        </td>
                        <td style={{textAlign: 'center'}}>
                          <div style={{display: 'flex', gap: 6, justifyContent: 'center'}}>
                            {appt.status === 'scheduled' ? (
                              <>
                                <button
                                  className="btn-icon primary"
                                  title="Mark Completed"
                                  onClick={() => handleStatusChange(appt.id, 'completed')}
                                >
                                  <CheckCircle size={14} />
                                </button>
                                <button
                                  className="btn-icon"
                                  title="Cancel"
                                  onClick={() => handleStatusChange(appt.id, 'cancelled')}
                                >
                                  <XCircle size={14} />
                                </button>
                                <button
                                  className="btn-icon"
                                  title="Edit"
                                  onClick={() => addToast('Edit functionality coming soon', 'info')}
                                >
                                  <Edit size={14} />
                                </button>
                              </>
                            ) : (
                              <button
                                className="btn-icon danger"
                                title="Delete"
                                onClick={() => setDeleteConfirm(appt.id)}
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                            <button
                              className="btn-icon"
                              title="View Details"
                              onClick={() => setSelectedAppt(appt)}
                            >
                              ⋮
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* APPOINTMENT DETAILS MODAL */}
      {selectedAppt && (
        <Modal
          open={true}
          onClose={() => setSelectedAppt(null)}
          title="Appointment Details"
          actions={[
            <button key="close" className="btn btn-s sm" onClick={() => setSelectedAppt(null)}>
              Close
            </button>
          ]}
        >
          <div style={{fontSize: 13}}>
            <div style={{marginBottom: 16}}>
              <strong>Patient:</strong> {selectedAppt.patient}
            </div>
            <div style={{marginBottom: 16}}>
              <strong>Doctor:</strong> {selectedAppt.doctor}
            </div>
            <div style={{marginBottom: 16}}>
              <strong>Date & Time:</strong> {formatDate(selectedAppt.date)} at {formatTime(selectedAppt.time)}
            </div>
            <div style={{marginBottom: 16}}>
              <strong>Type:</strong> {selectedAppt.type}
            </div>
            <div style={{marginBottom: 16}}>
              <strong>Status:</strong> <Badge s={selectedAppt.status} />
            </div>
            {selectedAppt.notes && (
              <div style={{marginBottom: 16}}>
                <strong>Notes:</strong>
                <p style={{color: 'var(--t2)', marginTop: 4}}>{selectedAppt.notes}</p>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* DELETE CONFIRMATION */}
      <ConfirmDialog
        open={deleteConfirm !== null}
        title="Delete Appointment"
        message="Are you sure you want to delete this appointment? This action cannot be undone."
        onConfirm={() => {
          handleDelete(deleteConfirm);
          setDeleteConfirm(null);
        }}
        onCancel={() => setDeleteConfirm(null)}
        confirmText="Delete"
        cancelText="Cancel"
        isDangerous={true}
      />
    </div>
  );
}

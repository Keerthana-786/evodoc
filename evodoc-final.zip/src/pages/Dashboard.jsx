import React, { useMemo } from 'react';
import { Calendar, Users, Clock, AlertCircle } from 'lucide-react';
import { useAppContext } from '../../hooks/AppContext';
import { EmptyState, Badge, InfoCard } from '../../components/UIComponents';
import { formatDate, formatTime, getToday } from '../../utils/helpers';

export default function DoctorDashboard() {
  const { appointments, patients, getDashboardStats, doctors } = useAppContext();
  const today = getToday();

  // Get current doctor info (in a real app, this would come from auth)
  const currentDoctor = doctors[0]; // Assuming logged-in doctor

  const stats = useMemo(() => {
    const todayAppts = appointments.filter(a => a.date === today && a.doctorId === currentDoctor?.id);
    const scheduledToday = todayAppts.filter(a => a.status === 'scheduled').length;
    const completedToday = todayAppts.filter(a => a.status === 'completed').length;

    const upcomingAppts = appointments.filter(
      a => a.date >= today && a.status === 'scheduled' && a.doctorId === currentDoctor?.id
    );

    return {
      todayTotal: todayAppts.length,
      scheduledToday,
      completedToday,
      upcomingCount: upcomingAppts.length,
      totalPatients: new Set(appointments
        .filter(a => a.doctorId === currentDoctor?.id)
        .map(a => a.patientId)).size
    };
  }, [appointments, today, currentDoctor?.id]);

  // Today's appointments
  const todayAppts = useMemo(() => {
    return appointments
      .filter(a => a.date === today && a.doctorId === currentDoctor?.id)
      .sort((a, b) => a.time.localeCompare(b.time));
  }, [appointments, today, currentDoctor?.id]);

  // Upcoming appointments (next 7 days)
  const upcomingAppts = useMemo(() => {
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 7);
    const nextWeek = endDate.toISOString().split('T')[0];

    return appointments
      .filter(a => a.date > today && a.date <= nextWeek && a.status === 'scheduled' && a.doctorId === currentDoctor?.id)
      .sort((a, b) => new Date(a.date) - new Date(b.date) || a.time.localeCompare(b.time))
      .slice(0, 8);
  }, [appointments, today, currentDoctor?.id]);

  // Recent appointments
  const recentAppts = useMemo(() => {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 7);
    const lastWeek = startDate.toISOString().split('T')[0];

    return appointments
      .filter(a => a.date >= lastWeek && a.date <= today && a.doctorId === currentDoctor?.id)
      .sort((a, b) => new Date(b.date) - new Date(a.date) || b.time.localeCompare(a.time))
      .slice(0, 5);
  }, [appointments, today, currentDoctor?.id]);

  return (
    <div className="pe">
      {/* WELCOME HEADER */}
      <div className="patient-header">
        <div style={{flex: 1}}>
          <div className="patient-name">Hello, {currentDoctor?.name || 'Doctor'}</div>
          <div style={{fontSize: 13, color: 'rgba(255,255,255,.7)', marginTop: 4}}>
            {currentDoctor?.specialty} • Welcome back to your dashboard
          </div>
        </div>
      </div>

      {/* STAT CARDS */}
      <div className="stat-grid">
        <InfoCard title="Today's Appointments" value={stats.todayTotal} icon={Calendar} color="var(--inf)" />
        <InfoCard title="Scheduled Today" value={stats.scheduledToday} icon={Clock} color="var(--wn)" />
        <InfoCard title="Completed Today" value={stats.completedToday} icon={Calendar} color="var(--ok)" />
        <InfoCard title="Total Patients" value={stats.totalPatients} icon={Users} color="var(--t)" />
      </div>

      {/* QUICK LINKS & ALERTS */}
      <div style={{display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 18, marginBottom: 18}}>
        {/* QUICK LINKS */}
        <div className="card">
          <div className="c-hd"><div className="c-t">Quick Links</div></div>
          <div className="c-bd" style={{display: 'flex', gap: 10, flexWrap: 'wrap', padding: '16px 20px'}}>
            <button className="btn btn-s sm" onClick={() => document.querySelector('.nav-i:nth-child(3)')?.click()}>
              👥 View Patient Records
            </button>
            <button className="btn btn-s sm" onClick={() => document.querySelector('.nav-i:nth-child(2)')?.click()}>
              📅 Full Schedule
            </button>
            <button className="btn btn-s sm" onClick={() => document.querySelector('.ic-b:nth-child(2)')?.click()}>
              ⚙️ Settings
            </button>
          </div>
        </div>

        {/* NOTIFICATIONS & ALERTS */}
        <div className="card" style={{borderColor: '#fcd34d'}}>
          <div className="c-hd" style={{background: 'var(--wnbg)', borderBottomColor: '#fde68a'}}>
            <div className="c-t" style={{color: '#92400e', display: 'flex', alignItems: 'center', gap: 6}}>
              <AlertCircle size={14} /> Notifications & Alerts
            </div>
          </div>
          <div className="c-bd" style={{padding: '12px 20px'}}>
             <div style={{fontSize: 13, color: '#92400e', fontWeight: 600}}>Priya Sharma</div>
             <div style={{fontSize: 12, color: '#b45309'}}>Lab results available for review.</div>
          </div>
        </div>
      </div>

      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18}}>
        {/* TODAY'S APPOINTMENTS */}
        <div className="card">
          <div className="c-hd">
            <div className="c-t">Today's Appointments</div>
            <div style={{fontSize: 12, color: 'var(--t3)'}}>{stats.todayTotal} total</div>
          </div>
          <div className="c-bd">
            {todayAppts.length === 0 ? (
              <EmptyState
                icon={Calendar}
                title="No Appointments Today"
                message="You have a free day today. Great!"
              />
            ) : (
              <div style={{display: 'flex', flexDirection: 'column', gap: 8}}>
                {todayAppts.map(appt => (
                  <div key={appt.id} className="ac" style={{cursor: 'default'}}>
                    <div className="at-b" style={{background: 'var(--tl)', color: 'var(--t)'}}>
                      <div className="at-h">{formatTime(appt.time)}</div>
                    </div>
                    <div className="a-inf">
                      <div className="a-pt">{appt.patient}</div>
                      <div className="a-mt">
                        <Badge s={appt.status} /> • {appt.type}
                      </div>
                      {appt.notes && <div style={{fontSize: 11, color: 'var(--t3)', marginTop: 4}}>{appt.notes}</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* QUICK STATS */}
        <div className="card">
          <div className="c-hd">
            <div className="c-t">Quick Stats</div>
          </div>
          <div className="c-bd">
            <div style={{display: 'flex', flexDirection: 'column', gap: 14}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 14, borderBottom: '1px solid var(--bd)'}}>
                <div>
                  <div style={{fontSize: 12, color: 'var(--t3)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 4}}>
                    Appointments This Month
                  </div>
                  <div style={{fontSize: 13, color: 'var(--tx)'}}>
                    {appointments.filter(a => {
                      const apptDate = new Date(a.date);
                      const today = new Date();
                      return apptDate.getMonth() === today.getMonth() && a.doctorId === currentDoctor?.id;
                    }).length}
                  </div>
                </div>
              </div>

              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 14, borderBottom: '1px solid var(--bd)'}}>
                <div>
                  <div style={{fontSize: 12, color: 'var(--t3)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 4}}>
                    Upcoming (7 days)
                  </div>
                  <div style={{fontSize: 13, color: 'var(--tx)'}}>
                    {stats.upcomingCount}
                  </div>
                </div>
              </div>

              <div>
                <div style={{fontSize: 12, color: 'var(--t3)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 4}}>
                  No-show Rate
                </div>
                <div style={{fontSize: 13, color: 'var(--tx)'}}>
                  2.3% (1 of 43)
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* UPCOMING APPOINTMENTS */}
      <div className="card" style={{marginTop: 18}}>
        <div className="c-hd">
          <div className="c-t">Upcoming Appointments (Next 7 Days)</div>
          <div style={{fontSize: 12, color: 'var(--t3)'}}>{stats.upcomingCount} appointments</div>
        </div>
        <div className="c-bd">
          {upcomingAppts.length === 0 ? (
            <div style={{textAlign: 'center', padding: 24, color: 'var(--t3)'}}>
              <p>No upcoming appointments in the next 7 days</p>
            </div>
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', gap: 8}}>
              {upcomingAppts.map(appt => (
                <div key={appt.id} className="ac" style={{cursor: 'default'}}>
                  <div className="at-b">
                    <div className="at-h" style={{fontSize: 11}}>{formatDate(appt.date).split(' ')[0]}</div>
                    <div className="at-d">{formatTime(appt.time)}</div>
                  </div>
                  <div className="a-inf">
                    <div className="a-pt">{appt.patient}</div>
                    <div className="a-mt">
                      {appt.type} • <Badge s={appt.status} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* RECENT COMPLETED */}
      <div className="card" style={{marginTop: 18}}>
        <div className="c-hd">
          <div className="c-t">Recent Activity (Last 7 Days)</div>
        </div>
        <div className="c-bd">
          {recentAppts.length === 0 ? (
            <div style={{textAlign: 'center', padding: 24, color: 'var(--t3)'}}>
              <p>No recent appointments</p>
            </div>
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', gap: 8}}>
              {recentAppts.map(appt => (
                <div key={appt.id} style={{
                  padding: 12,
                  background: 'var(--bg)',
                  borderRadius: 'var(--rs)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  opacity: appt.status === 'cancelled' ? 0.6 : 1
                }}>
                  <div>
                    <div style={{fontSize: 13, fontWeight: 500, color: 'var(--tx)'}}>{appt.patient}</div>
                    <div style={{fontSize: 11, color: 'var(--t3)', marginTop: 2}}>
                      {formatDate(appt.date)} at {formatTime(appt.time)}
                    </div>
                  </div>
                  <Badge s={appt.status} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

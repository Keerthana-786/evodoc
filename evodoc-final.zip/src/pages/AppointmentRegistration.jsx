import React, { useState } from 'react';
import { Plus, User, Stethoscope, Calendar, Clock, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../../hooks/AppContext';
import { SecTitle, Input, Sel, Dropdown, EmptyState, Modal } from '../../components/UIComponents';
import { formatDate, formatTime, validatePhone } from '../../utils/helpers';

export default function AppointmentRegistration() {
  const { patients, addPatient, doctors, appointments, addAppointment, addToast } = useAppContext();

  // Form states
  const [mode, setMode] = useState('existing'); // 'existing' or 'new'
  const [form, setForm] = useState({
    patientId: '',
    newPatientName: '',
    newPatientContact: '',
    newPatientEmail: '',
    doctorId: '',
    date: '',
    time: '',
    type: 'Consultation',
    notes: ''
  });
  const [errors, setErrors] = useState({});

  // Quick new patient form
  const [showNewPatientForm, setShowNewPatientForm] = useState(false);
  const [newPatientForm, setNewPatientForm] = useState({
    name: '',
    contact: '',
    email: ''
  });

  const handleFieldChange = (field, value) => {
    setForm(p => ({ ...p, [field]: value }));
    if (errors[field]) {
      setErrors(p => ({ ...p, [field]: '' }));
    }
  };

  const handleNewPatientChange = (field, value) => {
    setNewPatientForm(p => ({ ...p, [field]: value }));
  };

  const validateForm = () => {
    const e = {};

    if (mode === 'existing') {
      if (!form.patientId) e.patientId = 'Please select a patient';
    } else {
      if (!newPatientForm.name.trim()) e.newPatientName = 'Patient name is required';
      if (!newPatientForm.contact.trim()) e.newPatientContact = 'Contact number is required';
      else if (!validatePhone(newPatientForm.contact)) e.newPatientContact = 'Invalid phone number';
    }

    if (!form.doctorId) e.doctorId = 'Please select a doctor';
    if (!form.date) e.date = 'Please select a date';
    if (!form.time) e.time = 'Please select a time slot';

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleAddNewPatient = () => {
    if (!newPatientForm.name.trim() || !newPatientForm.contact.trim()) {
      addToast('Please fill in patient name and contact', 'error');
      return;
    }

    const newPt = addPatient({
      name: newPatientForm.name,
      contact: newPatientForm.contact,
      email: newPatientForm.email,
      dob: '',
      gender: '',
      blood: '',
      allergies: 'Not specified',
      conditions: 'Not specified',
      medications: 'Not specified',
      emergency: { name: '', relation: '', contact: '' }
    });

    if (newPt) {
      setForm(p => ({ ...p, patientId: newPt.id }));
      setShowNewPatientForm(false);
      setNewPatientForm({ name: '', contact: '', email: '' });
      setMode('existing');
    }
  };

  const [showConfirm, setShowConfirm] = useState(false);

  const handleSubmit = () => {
    if (!validateForm()) return;

    const selectedPatientId = mode === 'existing' ? form.patientId : form.patientId;
    const selectedDoctor = doctors.find(d => d.id === parseInt(form.doctorId));
    const selectedPatient = patients.find(p => p.id === selectedPatientId);

    if (!selectedDoctor || !selectedPatient) {
      addToast('Invalid selection. Please try again.', 'error');
      return;
    }

    setShowConfirm(true);
  };

  const confirmSubmit = () => {
    const selectedPatientId = mode === 'existing' ? form.patientId : form.patientId;
    const selectedDoctor = doctors.find(d => d.id === parseInt(form.doctorId));
    const selectedPatient = patients.find(p => p.id === selectedPatientId);

    const appointmentData = {
      patientId: selectedPatientId,
      patient: selectedPatient.name,
      doctorId: selectedDoctor.id,
      doctor: selectedDoctor.name,
      date: form.date,
      time: form.time,
      type: form.type,
      status: 'scheduled',
      notes: form.notes
    };

    const result = addAppointment(appointmentData);
    if (result) {
      // Reset form
      setForm({
        patientId: '',
        newPatientName: '',
        newPatientContact: '',
        newPatientEmail: '',
        doctorId: '',
        date: '',
        time: '',
        type: 'Consultation',
        notes: ''
      });
      setMode('existing');
      setErrors({});
      setShowConfirm(false);
    }
  };

  // Get available doctors (sorted by specialty)
  const availableDoctors = doctors.filter(d => d.available);

  // Get available time slots for selected doctor
  const selectedDoctor = doctors.find(d => d.id === parseInt(form.doctorId));
  const availableSlots = selectedDoctor?.slots || [];

  // Get this doctor's appointments on selected date
  const doctorApptsOnDate = appointments.filter(
    a => a.doctorId === parseInt(form.doctorId) && a.date === form.date
  );
  const bookedSlots = doctorApptsOnDate.map(a => a.time);
  const availableSlotsForDate = availableSlots.filter(slot => !bookedSlots.includes(slot));

  return (
    <div className="pe">
      <div className="card">
        <div className="c-hd">
          <div>
            <div className="c-t">Book Appointment</div>
            <div className="c-s">Schedule a new appointment for a patient with a doctor</div>
          </div>
        </div>

        <div className="c-bd">
          {/* PATIENT SELECTION */}
          <div className="fs">
            <SecTitle ic={<User size={12} />}>Patient Selection</SecTitle>

            <div style={{display: 'flex', gap: 12, marginBottom: 16}}>
              <button
                className={`btn ${mode === 'existing' ? 'btn-p' : 'btn-s'} sm`}
                onClick={() => setMode('existing')}
              >
                Existing Patient
              </button>
              <button
                className={`btn ${mode === 'new' ? 'btn-p' : 'btn-s'} sm`}
                onClick={() => setMode('new')}
              >
                <Plus size={12} />
                Add New Patient
              </button>
            </div>

            {mode === 'existing' ? (
              <div className="fg">
                {patients.length === 0 ? (
                  <EmptyState
                    icon={User}
                    title="No Patients Found"
                    message="No patients in the system yet. Click 'Add New Patient' to create one."
                  />
                ) : (
                  <>
                    <Sel
                      label="Select Patient"
                      req
                      value={form.patientId}
                      onChange={(e) => handleFieldChange('patientId', e.target.value)}
                      err={errors.patientId}
                    >
                      <option value="">Choose a patient...</option>
                      {patients.map(p => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.contact})
                        </option>
                      ))}
                    </Sel>
                    <button
                      className="btn btn-s sm"
                      onClick={() => setShowNewPatientForm(!showNewPatientForm)}
                      style={{justifyContent: 'center'}}
                    >
                      <Plus size={13} />
                      Or Add New Patient
                    </button>
                  </>
                )}
              </div>
            ) : (
              <div className="fg fg2">
                <Input
                  label="Patient Name"
                  req
                  placeholder="Full name"
                  value={newPatientForm.name}
                  onChange={(e) => handleNewPatientChange('name', e.target.value)}
                  err={errors.newPatientName}
                />
                <Input
                  label="Contact Number"
                  req
                  placeholder="+91 98765 43210"
                  value={newPatientForm.contact}
                  onChange={(e) => handleNewPatientChange('contact', e.target.value)}
                  err={errors.newPatientContact}
                />
                <Input
                  label="Email Address"
                  type="email"
                  placeholder="patient@email.com"
                  value={newPatientForm.email}
                  onChange={(e) => handleNewPatientChange('email', e.target.value)}
                />
                <button
                  className="btn btn-p sm"
                  onClick={handleAddNewPatient}
                  style={{justifyContent: 'center', gridColumn: '1/-1'}}
                >
                  <Plus size={13} />
                  Create & Select Patient
                </button>
              </div>
            )}
          </div>

          {/* ALLERGY WARNING */}
          {/* Temporarily removed */}

          {/* APPOINTMENT DETAILS */}
          <div className="fs">
            <SecTitle ic={<Stethoscope size={12} />}>Appointment Details</SecTitle>

            <div className="fg fg2">
              <div style={{gridColumn: '1/-1'}}>
                <div style={{fontSize: 12, fontWeight: 600, color: 'var(--tx)', marginBottom: 8}}>Select Doctor <span style={{color: 'var(--er)'}}>*</span></div>
                <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12}}>
                  {availableDoctors.map(d => (
                    <div 
                      key={d.id}
                      onClick={() => handleFieldChange('doctorId', d.id.toString())}
                      style={{
                        padding: 12,
                        borderRadius: 'var(--rs)',
                        border: `1.5px solid ${form.doctorId === d.id.toString() ? 'var(--t)' : 'var(--bd)'}`,
                        background: form.doctorId === d.id.toString() ? 'var(--tl)' : 'var(--wh)',
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 12
                      }}
                    >
                      <div style={{
                        width: 40, height: 40, borderRadius: '50%', 
                        background: 'var(--bg)', color: 'var(--t)', 
                        display: 'flex', alignItems: 'center', justifyContent: 'center', 
                        fontWeight: 'bold', fontSize: 14
                      }}>
                        {d.name.split(' ').map(n=>n[0]).join('').substring(0,2)}
                      </div>
                      <div>
                        <div style={{fontWeight: 600, fontSize: 14, color: 'var(--tx)'}}>{d.name}</div>
                        <div style={{fontSize: 12, color: 'var(--t2)'}}>{d.specialty}</div>
                      </div>
                    </div>
                  ))}
                </div>
                {errors.doctorId && <div className="ferr" style={{marginTop: 4}}>{errors.doctorId}</div>}
              </div>

              <Sel
                label="Appointment Type"
                value={form.type}
                onChange={(e) => handleFieldChange('type', e.target.value)}
              >
                <option>Consultation</option>
                <option>Follow-up</option>
                <option>Review</option>
                <option>Emergency</option>
                <option>Check-up</option>
              </Sel>

              <Input
                label="Date"
                req
                type="date"
                value={form.date}
                onChange={(e) => handleFieldChange('date', e.target.value)}
                err={errors.date}
              />

              <div style={{gridColumn: '1/-1'}}>
                <div style={{fontSize: 12, fontWeight: 600, color: 'var(--tx)', marginBottom: 8}}>Time Slot <span style={{color: 'var(--er)'}}>*</span></div>
                <div style={{
                  display: 'grid', 
                  gridTemplateColumns: 'repeat(auto-fill, minmax(85px, 1fr))', 
                  gap: 8
                }}>
                  {availableSlots.length > 0 ? availableSlots.map(slot => {
                    const isBooked = bookedSlots.includes(slot);
                    const isSelected = form.time === slot;
                    return (
                      <button
                        key={slot}
                        type="button"
                        disabled={isBooked}
                        onClick={() => handleFieldChange('time', slot)}
                        style={{
                          padding: '10px 4px',
                          borderRadius: 'var(--rs)',
                          border: `1.5px solid ${isSelected ? 'var(--t)' : isBooked ? '#fecaca' : 'var(--bd)'}`,
                          backgroundColor: isSelected ? 'var(--t)' : isBooked ? 'var(--erbg)' : 'var(--wh)',
                          color: isSelected ? '#fff' : isBooked ? 'var(--er)' : 'var(--tx)',
                          cursor: isBooked ? 'not-allowed' : 'pointer',
                          fontSize: '13px',
                          fontWeight: '500',
                          opacity: isBooked ? 0.6 : 1,
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center',
                          gap: 4,
                          transition: 'all 0.2s'
                        }}
                      >
                        {formatTime(slot)}
                        {isBooked && <span style={{fontSize: '9px', fontWeight: 'bold', textTransform: 'uppercase'}}>Booked</span>}
                      </button>
                    );
                  }) : (
                    <div style={{gridColumn: '1/-1', padding: '16px', textAlign: 'center', color: 'var(--t3)', background: 'var(--bg)', borderRadius: 'var(--rs)'}}>
                      {!form.doctorId ? 'Select a doctor first' : !form.date ? 'Select a date first' : 'No slots available'}
                    </div>
                  )}
                </div>
                {errors.time && <div className="ferr" style={{marginTop: 4}}>{errors.time}</div>}
              </div>

              <textarea
                className="fta"
                placeholder="Any notes or special requests..."
                value={form.notes}
                onChange={(e) => handleFieldChange('notes', e.target.value)}
                style={{minHeight: 60, gridColumn: '1/-1'}}
              />
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div style={{display: 'flex', gap: 9, justifyContent: 'flex-end', marginTop: 24}}>
            <button
              className="btn btn-s sm"
              onClick={() => {
                setForm({
                  patientId: '',
                  newPatientName: '',
                  newPatientContact: '',
                  newPatientEmail: '',
                  doctorId: '',
                  date: '',
                  time: '',
                  type: 'Consultation',
                  notes: ''
                });
                setErrors({});
                setMode('existing');
              }}
            >
              Clear Form
            </button>
            <button
              className="btn btn-p sm"
              onClick={handleSubmit}
            >
              <Calendar size={13} />
              Book Appointment
            </button>
          </div>
        </div>
      </div>

      {showConfirm && (
        <Modal
          open={showConfirm}
          onClose={() => setShowConfirm(false)}
          title="Confirm Appointment"
          actions={[
            <button key="cancel" className="btn btn-s sm" onClick={() => setShowConfirm(false)}>Cancel</button>,
            <button key="confirm" className="btn btn-p sm" onClick={confirmSubmit}>Confirm Booking</button>
          ]}
        >
          <div style={{fontSize: 13, display: 'flex', flexDirection: 'column', gap: 14}}>
            <p>Please confirm the appointment details below:</p>
            
            <div style={{padding: 16, background: 'var(--bg)', borderRadius: 'var(--rs)'}}>
              <div style={{display: 'grid', gridTemplateColumns: '100px 1fr', gap: 8, marginBottom: 8}}>
                <span style={{color: 'var(--t3)', fontWeight: 600}}>Patient:</span>
                <span style={{fontWeight: 600, color: 'var(--tx)'}}>{patients.find(p => p.id === parseInt(form.patientId))?.name || form.newPatientName}</span>
              </div>
              <div style={{display: 'grid', gridTemplateColumns: '100px 1fr', gap: 8, marginBottom: 8}}>
                <span style={{color: 'var(--t3)', fontWeight: 600}}>Doctor:</span>
                <span style={{fontWeight: 600, color: 'var(--tx)'}}>{doctors.find(d => d.id === parseInt(form.doctorId))?.name}</span>
              </div>
              <div style={{display: 'grid', gridTemplateColumns: '100px 1fr', gap: 8, marginBottom: 8}}>
                <span style={{color: 'var(--t3)', fontWeight: 600}}>Date & Time:</span>
                <span style={{fontWeight: 500, color: 'var(--tx)'}}>{formatDate(form.date)} at {formatTime(form.time)}</span>
              </div>
              <div style={{display: 'grid', gridTemplateColumns: '100px 1fr', gap: 8}}>
                <span style={{color: 'var(--t3)', fontWeight: 600}}>Type:</span>
                <span style={{color: 'var(--tx)'}}>{form.type}</span>
              </div>
            </div>
            
            {(patients.find(p => p.id === parseInt(form.patientId))?.allergies && patients.find(p => p.id === parseInt(form.patientId))?.allergies.toLowerCase() !== 'none' && patients.find(p => p.id === parseInt(form.patientId))?.allergies.toLowerCase() !== 'not specified') ? (
              <div style={{color: '#d32f2f', background: '#ffe6e6', padding: '10px 16px', borderRadius: 'var(--rs)', fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8}}>
                <AlertTriangle size={16} /> Patient has known allergies.
              </div>
            ) : null}
          </div>
        </Modal>
      )}
        </div>
      </div>
    </div>
  );
}

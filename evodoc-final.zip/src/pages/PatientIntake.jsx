import React, { useState } from 'react';
import { User, Phone, Activity, Save, Check } from 'lucide-react';
import { useAppContext } from '../../hooks/AppContext';
import { SecTitle, Input, Sel, Area } from '../../components/UIComponents';
import { validatePhone } from '../../utils/helpers';

export default function PatientIntake() {
  const emptyForm = {
    fullName: '',
    dob: '',
    gender: '',
    contact: '',
    email: '',
    eName: '',
    eRel: '',
    eCon: '',
    blood: '',
    allergies: '',
    conditions: '',
    medications: ''
  };

  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');
  const { addPatient, addToast } = useAppContext();

  const handleFieldChange = (field, value) => {
    setForm(prev => ({...prev, [field]: value}));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({...prev, [field]: ''}));
    }
  };

  const validate = () => {
    const newErrors = {};

    // Required fields validation
    if (!form.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!form.dob) {
      newErrors.dob = 'Date of birth is required';
    }

    if (!form.gender) {
      newErrors.gender = 'Please select gender';
    }

    if (!form.contact.trim()) {
      newErrors.contact = 'Contact number is required';
    } else if (!validatePhone(form.contact)) {
      newErrors.contact = 'Enter a valid phone number (at least 8 digits)';
    }

    if (!form.eName.trim()) {
      newErrors.eName = 'Emergency contact name is required';
    }

    if (!form.eCon.trim()) {
      newErrors.eCon = 'Emergency contact number is required';
    } else if (!validatePhone(form.eCon)) {
      newErrors.eCon = 'Enter a valid emergency contact phone number';
    }

    if (!form.blood) {
      newErrors.blood = 'Blood group is required';
    }

    return newErrors;
  };

  const handleSubmit = () => {
    const newErrors = validate();
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      // All validations passed, add patient to global state
      const result = addPatient({
        name: form.fullName.trim(),
        dob: form.dob,
        age: new Date().getFullYear() - new Date(form.dob).getFullYear(),
        gender: form.gender,
        contact: form.contact.trim(),
        email: form.email.trim() || '',
        blood: form.blood,
        allergies: form.allergies.trim() || 'None',
        conditions: form.conditions.trim() || 'None',
        medications: form.medications.trim() || 'None',
        emergency: {
          name: form.eName.trim(),
          relation: form.eRel.trim() || 'Not specified',
          contact: form.eCon.trim()
        }
      });

      if (result) {
        // Show success message
        setSuccessMessage(`✓ Patient ${form.fullName} registered successfully!`);
        
        // Clear form
        setForm(emptyForm);
        setErrors({});

        // Clear success message after 4 seconds
        setTimeout(() => {
          setSuccessMessage('');
        }, 4000);
      }
    }
  };

  const handleSaveDraft = () => {
    // Save to localStorage for draft recovery
    localStorage.setItem('patient_intake_draft', JSON.stringify(form));
    addToast('Draft saved to browser storage', 'info');
  };

  const handleClearForm = () => {
    setForm(emptyForm);
    setErrors({});
    setSuccessMessage('');
  };

  const calculateProgress = () => {
    const totalFields = 12;
    let filledFields = 0;
    Object.values(form).forEach(val => {
      if (val && String(val).trim() !== '') filledFields++;
    });
    return Math.round((filledFields / totalFields) * 100);
  };
  const progress = calculateProgress();

  return (
    <div className="pe">
      {/* SUCCESS MESSAGE */}
      {successMessage && (
        <div style={{
          padding: 14,
          marginBottom: 16,
          background: 'var(--okbg)',
          border: '1px solid #86efac',
          borderRadius: 'var(--rl)',
          color: 'var(--ok)',
          fontSize: 13,
          fontWeight: 500,
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }}>
          <Check size={16} />
          {successMessage}
        </div>
      )}

      <div className="card">
        <div className="c-hd">
          <div>
            <div className="c-t">Patient Registration</div>
            <div className="c-s">Complete all required fields to register a new patient</div>
          </div>
        </div>

        <div className="c-bd">
          {/* PROGRESS BAR */}
          <div style={{marginBottom: 24}}>
            <div style={{display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 600, color: 'var(--tx)', marginBottom: 8}}>
              <span>Form Completion</span>
              <span style={{color: progress === 100 ? 'var(--ok)' : 'var(--t)'}}>{progress}%</span>
            </div>
            <div style={{height: 6, background: 'var(--bd)', borderRadius: 3, overflow: 'hidden'}}>
              <div style={{
                height: '100%', 
                background: progress === 100 ? 'var(--ok)' : 'var(--t)', 
                width: `${progress}%`, 
                transition: 'width 0.4s cubic-bezier(0.16, 1, 0.3, 1), background-color 0.4s'
              }} />
            </div>
          </div>

          {/* PERSONAL INFORMATION SECTION */}
          <div className="fs">
            <SecTitle ic={<User size={12} />}>Personal Information</SecTitle>
            <div className="fg fg2">
              <Input
                label="Full Name"
                req
                placeholder="e.g. Priya Sharma"
                value={form.fullName}
                onChange={(e) => handleFieldChange('fullName', e.target.value)}
                err={errors.fullName}
              />

              <Input
                label="Date of Birth"
                req
                type="date"
                value={form.dob}
                onChange={(e) => handleFieldChange('dob', e.target.value)}
                err={errors.dob}
              />

              <Sel
                label="Gender"
                req
                value={form.gender}
                onChange={(e) => handleFieldChange('gender', e.target.value)}
                err={errors.gender}
              >
                <option value="">Select gender</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
                <option>Prefer not to say</option>
              </Sel>

              <Input
                label="Contact Number"
                req
                placeholder="+91 98765 43210"
                value={form.contact}
                onChange={(e) => handleFieldChange('contact', e.target.value)}
                err={errors.contact}
              />

              <Input
                label="Email Address"
                placeholder="patient@email.com"
                type="email"
                value={form.email}
                onChange={(e) => handleFieldChange('email', e.target.value)}
                span
              />
            </div>
          </div>

          {/* EMERGENCY CONTACT SECTION */}
          <div className="fs">
            <SecTitle ic={<Phone size={12} />}>Emergency Contact</SecTitle>
            <div className="fg fg3">
              <Input
                label="Contact Name"
                req
                placeholder="Full name"
                value={form.eName}
                onChange={(e) => handleFieldChange('eName', e.target.value)}
                err={errors.eName}
              />

              <Input
                label="Relationship"
                placeholder="e.g. Spouse, Parent"
                value={form.eRel}
                onChange={(e) => handleFieldChange('eRel', e.target.value)}
              />

              <Input
                label="Contact Number"
                req
                placeholder="+91 98765 43210"
                value={form.eCon}
                onChange={(e) => handleFieldChange('eCon', e.target.value)}
                err={errors.eCon}
              />
            </div>
          </div>

          {/* MEDICAL INFORMATION SECTION */}
          <div className="fs">
            <SecTitle ic={<Activity size={12} />}>Medical Information</SecTitle>
            <div className="fg fg2">
              <Sel
                label="Blood Group"
                req
                value={form.blood}
                onChange={(e) => handleFieldChange('blood', e.target.value)}
                err={errors.blood}
              >
                <option value="">Select blood group</option>
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(b =>
                  <option key={b}>{b}</option>
                )}
              </Sel>

              <Input
                label="Known Allergies"
                placeholder="e.g. Penicillin, Latex (or None)"
                value={form.allergies}
                onChange={(e) => handleFieldChange('allergies', e.target.value)}
              />

              <Area
                label="Chronic Conditions"
                placeholder="e.g. Hypertension, Diabetes (or None)"
                value={form.conditions}
                onChange={(e) => handleFieldChange('conditions', e.target.value)}
                style={{minHeight: 72}}
                span
              />

              <Area
                label="Current Medications"
                placeholder="e.g. Amlodipine 5mg once daily (or None)"
                value={form.medications}
                onChange={(e) => handleFieldChange('medications', e.target.value)}
                style={{minHeight: 72}}
                span
              />
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div style={{display: 'flex', gap: 9, justifyContent: 'flex-end'}}>
            <button
              className="btn btn-s sm"
              onClick={handleClearForm}
              title="Clear all fields"
            >
              Clear Form
            </button>

            <button
              className="btn btn-s sm"
              onClick={handleSaveDraft}
              title="Save form as draft to browser storage"
            >
              <Save size={13} />
              Save Draft
            </button>

            <button
              className="btn btn-p sm"
              onClick={handleSubmit}
              title="Submit and register patient"
            >
              <Check size={13} />
              Register Patient
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

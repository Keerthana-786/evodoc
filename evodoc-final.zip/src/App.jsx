import { useState } from "react";
import { Bell, Settings } from "lucide-react";
import { AppProvider, useAppContext } from "./hooks/AppContext";
import { Sidebar } from "./components/Sidebar";
import { Toaster } from "./components/UIComponents";
import { PAGE_META } from "./data/pageMeta";

// Nurse Pages
import PatientIntake from "./pages/PatientIntake";
import AppointmentRegistration from "./pages/AppointmentRegistration";
import AppointmentList from "./pages/AppointmentList";

// Doctor Pages
import DoctorDashboard from "./pages/Dashboard";
import DoctorAppointments from "./pages/Appointments";
import PatientDetails from "./pages/PatientDetails";

import "./styles/index.css";

function AppContent() {
  const { loading, addToast } = useAppContext();
  const [portal, setPortal] = useState('nurse');
  const [page, setPage] = useState('appts');
  const [showSettings, setShowSettings] = useState(false);

  const nav = (p) => setPage(p);
  const info = PAGE_META[page] || { t: 'EvoDoc', s: '' };

  const renderPage = () => {
    if (loading) {
      return (
        <div style={{padding: 40, textAlign: 'center'}}>
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16}}>
            <div style={{
              width: 50,
              height: 50,
              border: '3px solid var(--bg)',
              borderTop: '3px solid var(--t)',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite'
            }}/>
            <p style={{color: 'var(--t2)'}}>Loading application...</p>
          </div>
        </div>
      );
    }

    // NURSE PORTAL
    if (portal === 'nurse') {
      switch (page) {
        case 'intake': return <PatientIntake />;
        case 'reg': return <AppointmentRegistration />;
        case 'appts': return <AppointmentList />;
        case 'nur-pts': return <PatientDetails />;
        default:
          return (
            <div style={{padding: 40, textAlign: 'center'}}>
              <h2 style={{color:'var(--t2)', marginBottom:10}}>Page Not Found</h2>
              <p style={{color:'var(--t3)'}}>This page is not available in Nurse portal.</p>
            </div>
          );
      }
    }

    // DOCTOR PORTAL
    if (portal === 'doctor') {
      switch (page) {
        case 'doc-dash': return <DoctorDashboard />;
        case 'doc-appts': return <DoctorAppointments />;
        case 'doc-pts': return <PatientDetails />;
        default:
          return (
            <div style={{padding: 40, textAlign: 'center'}}>
              <h2 style={{color:'var(--t2)', marginBottom:10}}>Page Not Found</h2>
              <p style={{color:'var(--t3)'}}>This page is not available in Doctor portal.</p>
            </div>
          );
      }
    }
  };

  return (
    <div className="app">
      <Sidebar portal={portal} setPortal={setPortal} page={page} setPage={setPage} />
      <div className="main">
        <div className="topbar">
          <div>
            <div className="pg-t">{info.t}</div>
            <div className="pg-s">{info.s}</div>
          </div>
          <div className="tb-acts">
            <div className="ic-b nd" title="Notifications">
              <Bell size={14} />
            </div>
            <div className="ic-b" title="Settings" onClick={() => setShowSettings(true)}>
              <Settings size={14} />
            </div>
          </div>
        </div>
        <div className="cont">
          {renderPage()}
        </div>
      </div>
      <Toaster />
      
      {showSettings && (
        <div className="ov" onClick={() => setShowSettings(false)}>
          <div className="md" onClick={e => e.stopPropagation()}>
            <div className="md-t">System Settings</div>
            <div className="md-b">Configure your application preferences.</div>
            <div className="fg fgp" style={{gap: '14px', marginBottom: '20px'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                <span className="fl" style={{fontSize: '13px', color: 'var(--tx)', letterSpacing: 0}}>Dark Mode</span>
                <input type="checkbox" style={{cursor: 'pointer'}} />
              </div>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                <span className="fl" style={{fontSize: '13px', color: 'var(--tx)', letterSpacing: 0}}>Email Notifications</span>
                <input type="checkbox" defaultChecked style={{cursor: 'pointer'}} />
              </div>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                <span className="fl" style={{fontSize: '13px', color: 'var(--tx)', letterSpacing: 0}}>Compact View</span>
                <input type="checkbox" style={{cursor: 'pointer'}} />
              </div>
            </div>
            <div style={{display: 'flex', justifyContent: 'flex-end', gap: '10px'}}>
              <button className="btn btn-s" onClick={() => setShowSettings(false)}>Cancel</button>
              <button className="btn btn-p" onClick={() => { addToast("Settings saved successfully", "success"); setShowSettings(false); }}>Save Changes</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
